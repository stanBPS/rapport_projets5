
Site du projet: https://stanbps.github.io/rapport_projets5/

Pour utiliser l'application en local.

Pre-requis
- Installer un IDE pour Java (recommandation Eclipse)
- Installer WampServer 

Installation de la base de données
	1.lancez WampServer quand le logo est vert dans la barre de tâche se rendre sur un navigateur et entrer http://localhost/
	2.Ouvrez phpMyAdmin (dans la partie outils).(login par defaut: root/mot de passe: )
	3.Créer une nouvelle base (recommandation nom bdd_projets5)
	4.Cliquez sur le nom de la base de données(bdd_projets5) qui recevra les informations importées. La page se rafraîchira pour afficher les informations relatives à la base de données sélectionnée.
	5.Cliquez sur l’onglet « Importer ».
	6.Cliquez sur le bouton « choisir un fichier » de la section « Fichier à importer » .
	7.Votre navigateur vous invitera à repérer sur votre ordinateur le fichier (Code_source/BDD/bdd_projets5_with_data.sql ou bdd_projets5_without_data.sql) de la base de données.
	8.Une fois le fichier repéré et sélectionné. Cliquez sur le bouton « Exécuter ».
P.S: Si vous avez un autre login ou mot de passe vous pouvez le changer dans le fichier "conf.properties"

Lancement de l'application avec les .jar
	1.Lancer ProjetS5.jar (dans le dossier Executable)
	2.Choisir un numero de port( par defaut:8952)
	3.Lancer capteur.jar (dans le dossier Executable)
	4.Choisir un numero de port( par defaut:8952)
	5.Dans l'application capteur.jar, ajouter un ou des capteur à l'aide du menu (un fichier capteur.csv (dans le dossier Executable) vous est fournie avec des capteurs déjà enregistré)
Une fois les differzentes étapes remplies, vous pouvez maintenant utiliser l'application projetS5.jar et Capteur.jar.

Lancement avec Eclipse
	1.Importer le projet dans Eclipse 
		- Ouvrir Eclipse
		- Clique droit à gauche dans la partie "Package Explorer". Cliquez sur "import"
		- Dans "General", Selectionner "Projects from Folder or Archive". Cliquez sur le bouton "next" 
		- Cliquez sur le bouton "Directory..."
		- Eclipse vous invitera à repérer sur votre ordinateur le dossier (ProjetS5 par exemple qui est dans le dossier Code_source/JAVA fichier .zip) pour le projet.
		- Cliquez sur le bouton "Finish"
	2.Executer l'application
		- Dans le fichier src puis dans le package se trouve AppMain.java, Clique droit sur le fichier et selectionner  "Run As" -> "java application"
		- Choisir un numero de port( par defaut:8952)
		- Lancer capteur.jar
		- Choisir un numero de port( par defaut:8952)
		- Dans l'application capteur.jar, ajouter un ou des capteur à l'aide du menu (un fichier capteur.csv vous est fournie avec des capteurs déjà enregistré)
Une fois les differzentes étapes remplies, vous pouvez maintenant utiliser l'application et Capteur.jar.