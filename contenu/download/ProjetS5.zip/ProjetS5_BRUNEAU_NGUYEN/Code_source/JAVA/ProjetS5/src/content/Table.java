package content;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;

import capteur.Capteur;
import server.Server;

public class Table extends JPanel {
	private static final long serialVersionUID = 1L;
	public static ModeleTable modele;
	public static JComboBox<String> filtre_batiment;
	public static JComboBox<String> filtre_fluide;
	public static TableColumnModel modeleColonne;

	public Table() {

		this.setBackground(Color.WHITE);

		this.setLayout(new BorderLayout());

		/*---------------------------FILTRE------------------------------*/
		String[] batTAb = { "Tous", "U1", "U2", "U3", "U4" };
		String[] fluideTAb = { "Tous", "EAU", "ELECTRICITE", "TEMPERATURE", "AIRCOMPRIME" };
		filtre_batiment = new JComboBox<>(batTAb);
		filtre_fluide = new JComboBox<>(fluideTAb);

		JPanel filter = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		filter.add(filtre_fluide);
		filter.add(filtre_batiment);
		/*----------------------TABLEAU----------------------------------*/
		modele = new ModeleTable();

		filtre_batiment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modele.filter(filtre_fluide.getSelectedItem(), filtre_batiment.getSelectedItem());
			}
		});
		filtre_fluide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modele.filter(filtre_fluide.getSelectedItem(), filtre_batiment.getSelectedItem());
			}
		});
		JTable tableau = new JTable(modele);
		modeleColonne=tableau.getColumnModel();
		for(int i=0; i<6;i++) {
			modeleColonne.getColumn(i).setCellRenderer(new RenduTableau());
		}
		this.add(filter, BorderLayout.PAGE_START);
		this.add(new JScrollPane(tableau), BorderLayout.CENTER);

	}

	public class ModeleTable extends AbstractTableModel {
		private static final long serialVersionUID = 1L;
		TreeMap<String, Capteur> filterCapteurs = new TreeMap<>();

		public void filter(Object type, Object bat) {
			TreeMap<String, Capteur> tmp = new TreeMap<>();
			tmp.clear();
			filterCapteurs.clear();
			for (Entry<String, Capteur> entry : Server.cloneCapteurs.entrySet()) {
				if (entry.getValue().getType().equals(type)) {
					tmp.put(entry.getKey(), entry.getValue());
				}
				if (type.equals("Tous")) {
					tmp.put(entry.getKey(), entry.getValue());
				}
			}
			for (Entry<String, Capteur> entry : tmp.entrySet()) {
				if (entry.getValue().getBatiment().equals(bat)) {
					filterCapteurs.put(entry.getKey(), entry.getValue());
				}
				if (bat.equals("Tous")) {
					filterCapteurs.put(entry.getKey(), entry.getValue());
				}
			}
			this.fireTableDataChanged();
		}

		@Override
		public int getRowCount() {
			int nb = 0;
			for (Entry<String, Capteur> entry : filterCapteurs.entrySet()) {
				if (entry.getValue().isActive()) {
					nb++;
				}
			}
			return nb;
		}

		@Override
		public int getColumnCount() {
			return 6;
		}

		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
			int i = 0;
			Capteur c = null;
			Iterator<Capteur> itr = filterCapteurs.values().iterator();
			while (itr.hasNext() && rowIndex >= i) {
				c = itr.next();
				i++;
			}
			c = c.isActive() ? c : null;
			if (c != null) {
				switch (columnIndex) {
				case 0:
					return c.getNom();
				case 1:
					return c.getType();
				case 2:
					return c.getBatiment();
				case 3:
					return c.getEtage();
				case 4:
					return c.getLieu();
				case 5:
					List<Float> list = c.getList();
					return list.size() > 0 ? list.get(list.size() - 1) : null;
				default:
					return null;
				}
			}
			return null;
		}

		@Override
		public String getColumnName(int indiceColonne) {
			switch (indiceColonne) {
			case 0:
				return "Capteur";
			case 1:
				return "Type";
			case 2:
				return "Batiment";
			case 3:
				return "Etage";
			case 4:
				return "Lieu";
			case 5:
				return "Valeur";
			default:
				return null;
			}
		}
		
		public Class<?> getColumnClass(int c) {
			return getValueAt(0, c)==null? Float.class: getValueAt(0, c).getClass();
		}

		public boolean isCellEditable(int indiceLigne, int indiceColonne) {
			return false;
		}
		
		public Capteur getCapteur(int row) {
			int i = 0;
			Capteur c = null;
			Iterator<Capteur> itr = filterCapteurs.values().iterator();
			while (itr.hasNext() && row >= i) {
				c = itr.next();
				i++;
			}
			return c;
		}

	}

	public class RenduTableau extends DefaultTableCellRenderer {
		private static final long serialVersionUID = 1L;

		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
			Capteur c= ((ModeleTable) table.getModel()).getCapteur(row);
			if(c.isRed()) {
				setForeground(Color.RED);
			}
			else {
				setForeground(table.getForeground());
			}
			return this;
		}
	}
}
