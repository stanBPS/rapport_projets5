package database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Properties;


import javax.swing.tree.DefaultMutableTreeNode;


public class Database {

	Connection connection;
	ResultSet resultSet;
	PreparedStatement statement;
	
	public Connection connexionDatabase() {
		Properties props = new Properties();
		try (FileInputStream file = new FileInputStream("conf.properties")){
			props.load(file);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		String url = props.getProperty("jdbc.url");
		String login = props.getProperty("jdbc.login");
		String password = props.getProperty("jdbc.password");
		try {
			Class.forName(props.getProperty("jdbc.driver.class"));
			connection = DriverManager.getConnection(url,login,password);
		}catch (ClassNotFoundException e) {
			System.out.println("Error, Driver upload");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return connection;
		
	}
	
	public Connection fermerConnexion() {
		try {
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
	
	public ResultSet executerRequete(String sql) {
		connexionDatabase();
		try{
			statement = connection.prepareStatement(sql);
			try{
				resultSet = statement.executeQuery();
			}catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return resultSet;
	}
	
	public String requeteUpdate(String sql) {
		connexionDatabase();
		String result = "";
		try {
			statement = connection.prepareStatement(sql);
			statement.executeUpdate();
			result = sql;
			
		}catch (Exception e) {
		}
		return result;
	}
	
	public ResultSet querySelectAll(String nomTable) {
		connexionDatabase();
		String sql= "SELECT * FROM "+ nomTable;
		return this.executerRequete(sql);
	}

	
	public String addToTableCapteur(String nomC, String TypeC, String nomB, String Etage, String Lieu,float min,float max,boolean active) {
		connexionDatabase();
		int etage = Integer.valueOf(Etage);
		
		String sql= "INSERT INTO capteur(NomC,NomB,Etage,TypeC,Lieu,seuilMin,seuilMax,active) VALUES('"+nomC+"', '"+nomB+"', '"+etage+"','"+TypeC+"','"+Lieu+"',"+min+","+max+","+active+")";
		return this.requeteUpdate(sql);
	}
	
	public String addToTableValeur(String nomC, float valeur, Timestamp sqlDate) {
		connexionDatabase();
		String sql= "INSERT INTO valeur(NomC,Valeur,Date)  VALUES('"+nomC+"', "+valeur+", '"+sqlDate+"')";
		return this.requeteUpdate(sql);
	}
	
	public ResultSet getdistinct(String nomTable) {
		String sql= "SELECT DISTINCT(NomB) FROM "+ nomTable ;	
		return this.executerRequete(sql);
	}
	
	public ResultSet getByEtage(String nomTable,String bat) {
		String sql= "SELECT DISTINCT(Etage) FROM "+ nomTable + " WHERE NomB='"+bat+"'";	
		return this.executerRequete(sql);
	}
	
	public ResultSet getByFluide(String nomTable,String type) {
		String sql= "SELECT * FROM "+ nomTable + " WHERE TypeC='"+type+"'";	
		return this.executerRequete(sql);
	}
	
	
	public ResultSet getCapteur(String nomTable,int etage,String bat) {
		String sql= "SELECT NomC FROM "+ nomTable + " WHERE NomB='"+bat+"' and etage="+etage;	
		return this.executerRequete(sql);
	}
	
	public ResultSet getInfoCapteur(String NomC) {
		String sql= "SELECT * FROM capteur WHERE NomC='"+NomC+"'";	
		return this.executerRequete(sql);
	}
	
	public ResultSet getSeuilBase(String TypeC) {
		String sql= "SELECT * FROM type WHERE TypeC='"+TypeC+"'";	
		return this.executerRequete(sql);
	}
	
	public float getSeuilBaseMinOrMax(String seuil,String TypeC) {
		float res=0;
		String sql= "SELECT "+seuil +" FROM type WHERE TypeC='"+TypeC+"'";	
		ResultSet rs = executerRequete(sql);
		try {
			while (rs.next()) {
				res= rs.getFloat(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	public ResultSet getSeuilCapteur(String NomC) {
		String sql= "SELECT seuilMin,seuiMax FROM capteur WHERE NomC='"+NomC+"'";	
		return this.executerRequete(sql);
	}
	
	public String insertActive(String NomC, boolean active) {
		String sql = "INSERT INTO capteur(active) VALUES("+active+") WHERE NomC='"+NomC+"'";
		return this.requeteUpdate(sql);
	}
	
	public String changeActive(String NomC, boolean active) {
		String sql = "UPDATE capteur SET active="+active+" WHERE NomC='"+NomC+"'";
		return this.requeteUpdate(sql);
	}
	
	public String changeSeuilMax(String NomC, float value) {
		String sql = "UPDATE capteur SET seuilMax="+value+" WHERE NomC='"+NomC+"'";
		return this.requeteUpdate(sql);
	}
	
	public String changeSeuilMin(String NomC, float value) {
		String sql = "UPDATE capteur SET seuilMin="+value+" WHERE NomC='"+NomC+"'";
		return this.requeteUpdate(sql);
	}
	
	public void miseAJourTree(DefaultMutableTreeNode racine) {
		Statement stmt1;
		Statement stmt2;
		try {
			connexionDatabase();
			racine.removeAllChildren();
			stmt1 = connection.createStatement();
			stmt2 = connection.createStatement();
			ResultSet rst = stmt1.executeQuery("SELECT DISTINCT(NomB) FROM capteur ORDER BY NomB");
			while (rst.next()) {
				String NomB = rst.getString("NomB");
				DefaultMutableTreeNode batiment =new DefaultMutableTreeNode(NomB);
				racine.add(batiment);
				ResultSet rst2 = stmt2.executeQuery("SELECT DISTINCT(Etage) FROM capteur WHERE NomB='"+NomB+"' ORDER BY Etage");
				while (rst2.next()) {
					String Etage = String.valueOf(rst2.getInt("Etage"));
					DefaultMutableTreeNode etage =new DefaultMutableTreeNode(Etage);
					batiment.add(etage);
					ResultSet rst3=getCapteur("capteur",rst2.getInt("Etage"),NomB);
					while (rst3.next()) {
						etage.add(new DefaultMutableTreeNode(rst3.getString(1)));
					}
				}
			}
			rst.close();
			stmt2.close();
			stmt1.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
