package content;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;


import capteur.Capteur;
import database.Database;





public class Gestion extends JPanel {
	private static final long serialVersionUID = 1L;
	

		static Database d = new Database();
		public static DefaultTreeModel model;
		public static JTree tree;
		static DefaultMutableTreeNode root;
		static JPanel info;
		
		SpinnerNumberModel modelMin = new SpinnerNumberModel((float) 0.0, -1000.0, 1000.0, 0.1);
		SpinnerNumberModel modelMax = new SpinnerNumberModel((float) 0.0, -1000.0, 1000.0, 0.1);
		JSpinner spinnerMax;
		JSpinner spinnerMin;
		DefaultMutableTreeNode capteurSelect;
		
		JLabel nomC = new JLabel("",SwingConstants.CENTER);
		JLabel NomB = new JLabel("",SwingConstants.CENTER);
		JLabel Etage = new JLabel("",SwingConstants.CENTER);
		JLabel TypeC = new JLabel("",SwingConstants.CENTER);
		JLabel Lieu = new JLabel("",SwingConstants.CENTER);
		JLabel seuilMax= new JLabel("0",SwingConstants.CENTER);
		JLabel seuilMin= new JLabel("0",SwingConstants.CENTER);
		JLabel Unite= new JLabel("",SwingConstants.CENTER);
		JLabel Active= new JLabel("",SwingConstants.CENTER);
		
		public Gestion() {
			this.setBackground(Color.WHITE);
			this.setLayout(new BorderLayout());

			root = new DefaultMutableTreeNode("Universit� Paul Sabatier");
			d.miseAJourTree(root);
			
			tree = new JTree(root);
			
			tree.addTreeSelectionListener(new TreeSelectionListener() {
				
				@Override
				public void valueChanged(TreeSelectionEvent e) {
					capteurSelect= (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
					
					if(capteurSelect==null) {
						return;
					}
					if(capteurSelect.isLeaf()) {
						FillInfo(capteurSelect.toString());
						spinnerMin.setValue(Float.valueOf(seuilMin.getText()));
						spinnerMax.setValue(Float.valueOf(seuilMax.getText()));
						}
					info.validate();
					}
					
				});
			
			
			info = new JPanel();
			info.setLayout(new GridLayout(3,5,10,10));
			
			JPanel cap_panel = new JPanel();
			cap_panel.setBackground(new Color(0xF3F3F3));
			cap_panel.setLayout(new BorderLayout());
			JLabel capteur_label = new JLabel("CAPTEUR",SwingConstants.CENTER);
			cap_panel.add(capteur_label,BorderLayout.PAGE_START);
			cap_panel.add(nomC,BorderLayout.CENTER);
			
			JPanel type_panel = new JPanel();
			type_panel.setBackground(new Color(0xF3F3F3));
			type_panel.setLayout(new BorderLayout());
			JLabel type_label = new JLabel("FLUIDE",SwingConstants.CENTER);
			type_panel.add(type_label,BorderLayout.PAGE_START);
			type_panel.add(TypeC,BorderLayout.CENTER);
			
			JPanel Batiment_panel = new JPanel();
			Batiment_panel.setBackground(new Color(0xF3F3F3));
			Batiment_panel.setLayout(new BorderLayout());
			JLabel Batiment_label = new JLabel("BATIMENT",SwingConstants.CENTER);
			Batiment_panel.add(Batiment_label,BorderLayout.PAGE_START);
			Batiment_panel.add(NomB,BorderLayout.CENTER);
			
			JPanel Etage_panel = new JPanel();
			Etage_panel.setBackground(new Color(0xF3F3F3));
			Etage_panel.setLayout(new BorderLayout());
			JLabel Etage_label = new JLabel("ETAGE",SwingConstants.CENTER);
			Etage_panel.add(Etage_label,BorderLayout.PAGE_START);
			Etage_panel.add(Etage,BorderLayout.CENTER);
			
			JPanel Lieu_panel = new JPanel();
			Lieu_panel.setBackground(new Color(0xF3F3F3));
			Lieu_panel.setLayout(new BorderLayout());
			JLabel Lieu_label = new JLabel("LIEU",SwingConstants.CENTER);
			Lieu_panel.add(Lieu_label,BorderLayout.PAGE_START);
			Lieu_panel.add(Lieu,BorderLayout.CENTER);
			
			ImageIcon image_button = new ImageIcon("images/check.png");	
			Image newImage = image_button.getImage().getScaledInstance(-1, -1, Image.SCALE_SMOOTH);
			image_button = new ImageIcon(newImage);
			
			JPanel seuilMin_panel = new JPanel();
			seuilMin_panel.setBackground(new Color(0xF3F3F3));
			seuilMin_panel.setLayout(new BorderLayout());
			JLabel seuilMin_label = new JLabel("SEUIL MIN",SwingConstants.CENTER);
			seuilMin_panel.add(seuilMin_label,BorderLayout.PAGE_START);
			seuilMin_panel.add(seuilMin,BorderLayout.CENTER);
			
			JPanel spinnerMin_panel = new JPanel();
			JPanel spinnerMin_panel2 = new JPanel();
			spinnerMin_panel.setLayout(new FlowLayout());
			spinnerMin_panel2.setLayout(new GridLayout(1,2,5,5));
			spinnerMin_panel.add(spinnerMin_panel2);
			spinnerMin = new JSpinner(modelMin);
			spinnerMin.setPreferredSize(new Dimension(50,30));
			spinnerMin_panel2.add(spinnerMin);
			JButton min_button = new JButton(image_button);
			min_button.setPreferredSize(new Dimension(50,30));
			spinnerMin_panel2.add(min_button);
			seuilMin_panel.add(spinnerMin_panel,BorderLayout.SOUTH);
			
			min_button.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					d.changeSeuilMin(capteurSelect.toString(), ((Double) spinnerMin.getValue()).floatValue());
					FillInfo(capteurSelect.toString()).setMin(((Double) spinnerMin.getValue()).floatValue());
				}
			});
			
			
			JPanel seuilMax_panel = new JPanel();
			seuilMax_panel.setLayout(new BorderLayout());
			seuilMax_panel.setBackground(new Color(0xF3F3F3));
			JLabel seuilMax_label = new JLabel("SEUIL MAX",SwingConstants.CENTER);
			seuilMax_panel.add(seuilMax_label,BorderLayout.PAGE_START);
			seuilMax_panel.add(seuilMax,BorderLayout.CENTER);
			
			JPanel spinnerMax_panel = new JPanel();
			JPanel spinnerMax_panel2 = new JPanel();
			spinnerMax_panel.setLayout(new FlowLayout());
			spinnerMax_panel2.setLayout(new GridLayout(1,2,5,5));
			spinnerMax_panel.add(spinnerMax_panel2);
			spinnerMax = new JSpinner(modelMax);
			spinnerMax.setPreferredSize(new Dimension(50,30));
			spinnerMax_panel2.add(spinnerMax);
			JButton max_button = new JButton(image_button);
			max_button.setPreferredSize(new Dimension(50,30));
			spinnerMax_panel2.add(max_button);
			seuilMax_panel.add(spinnerMax_panel,BorderLayout.SOUTH);
			
			max_button.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					d.changeSeuilMax(capteurSelect.toString(), ((Double) spinnerMax.getValue()).floatValue());
					
					FillInfo(capteurSelect.toString()).setMax(((Double) spinnerMax.getValue()).floatValue());
				}
			});
			
			JPanel Unite_panel = new JPanel();
			Unite_panel.setBackground(new Color(0xF3F3F3));
			Unite_panel.setLayout(new BorderLayout());
			JLabel Unite_label = new JLabel("UNITE",SwingConstants.CENTER);
			Unite_panel.add(Unite_label,BorderLayout.PAGE_START);
			Unite_panel.add(Unite,BorderLayout.CENTER);
			
			JPanel active_panel = new JPanel();
			active_panel.setBackground(new Color(0xF3F3F3));
			active_panel.setLayout(new BorderLayout());
			JLabel active_label = new JLabel("ACTIVE",SwingConstants.CENTER);
			active_panel.add(active_label,BorderLayout.PAGE_START);
			active_panel.add(Active,BorderLayout.CENTER);
			
			info.add(cap_panel);
			info.add(type_panel);
			info.add(Batiment_panel);
			info.add(Etage_panel);
			info.add(Lieu_panel);
			info.add(seuilMin_panel);
			info.add(seuilMax_panel);
			info.add(Unite_panel);
			info.add(active_panel);

			JScrollPane info_scroll =  new JScrollPane(info);
			info_scroll.setPreferredSize(new Dimension(400,400));
			
			JSplitPane split_panel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,new JScrollPane(tree),info_scroll);
			this.add(split_panel,BorderLayout.CENTER);
			
			
		}

		
		public Capteur FillInfo(String NomC){
			ResultSet rs =d.getInfoCapteur(NomC);
			Capteur c = null;
			try {
				while (rs.next()) {
					 nomC.setText(rs.getString(1)); 
					 NomB.setText(rs.getString(2));
					 Etage.setText(rs.getString(3));
					 TypeC.setText(rs.getString(4));
					 Lieu.setText(rs.getString(5));
					 seuilMax.setText(rs.getString(7));
					 seuilMin.setText(rs.getString(6));
					 
					 if (Integer.valueOf(rs.getString(8)) == 0) {
						 Active.setText("Desactive");
					 }else {
						 Active.setText("Active");
					 }
					 ResultSet rs1 = d.getSeuilBase((rs.getString(4)));
					 while (rs1.next()) {
						 Unite.setText(rs1.getString(4));				
					}
					 c = new Capteur(rs.getString(1), rs.getString(4), rs.getString(2), rs.getString(3), rs.getString(5), Boolean.valueOf(rs.getString(8)));
					
				}
			}catch (SQLException e) {
				// TODO: handle exception
			}
			return c;
		}
	

}
