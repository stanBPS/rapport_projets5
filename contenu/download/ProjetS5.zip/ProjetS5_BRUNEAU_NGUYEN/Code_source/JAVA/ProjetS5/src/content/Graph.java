package content;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.SqlDateModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import database.Database;

public class Graph extends JPanel{
	private static final long serialVersionUID = 1L;
	Database d = new Database();
	static String query="";
	static XYSeriesCollection dataset = new XYSeriesCollection();
	static JFreeChart chart=ChartFactory.createXYLineChart("","Date", "Value",dataset,PlotOrientation.VERTICAL, true, true, false);
	static ChartPanel chartPanel = new ChartPanel(chart);
	static int nb=0;
	
	public Graph() {
		this.setBackground(Color.WHITE);
		this.setLayout(new BorderLayout());
		
		JPanel header =new JPanel(new FlowLayout(FlowLayout.CENTER,20,0));
		JPanel bottom= new JPanel(new FlowLayout(FlowLayout.CENTER,20,0));
		JComboBox<String> filtre_fluide=new JComboBox<>();
		JComboBox<String> filtre_capteur=new JComboBox<>();
		filtre_fluide.addItem("---Chosir le type fluide---");
		filtre_fluide.addItem("EAU");
		filtre_fluide.addItem("ELECTRICITE");
		filtre_fluide.addItem("TEMPERATURE");
		filtre_fluide.addItem("AIRCOMPRIME");
		filtre_capteur.addItem("---Chosir le capteur---");
		filtre_fluide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!filtre_fluide.getSelectedItem().equals("---Chosir le type fluide---")){
					try {
						ResultSet rst= d.getByFluide("capteur", (String)filtre_fluide.getSelectedItem());
						filtre_capteur.removeAllItems();
						filtre_capteur.addItem("---Chosir le capteur---");
						while(rst.next()) {
							filtre_capteur.addItem(rst.getString("NomC"));
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else {
					filtre_capteur.removeAllItems();
					filtre_capteur.addItem("---Chosir le capteur---");
				}
			}
		});
		
		SqlDateModel model = new SqlDateModel();
		Properties p = new Properties();
		p.put("text.today", "Aujourd'hui");
		p.put("text.month", "Mois");
		p.put("text.year", "Ann�e");
		JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
		JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());
		
		SqlDateModel model2 = new SqlDateModel();
		JDatePanelImpl datePanel2 = new JDatePanelImpl(model2, p);
		JDatePickerImpl datePicker2 = new JDatePickerImpl(datePanel2, new DateLabelFormatter());
		

		
		JPanel dateBegin=new JPanel(new FlowLayout(FlowLayout.CENTER,0,0));
		dateBegin.add(new JLabel("D�but"));
		dateBegin.add(datePicker);
		
		JPanel dateEnd=new JPanel(new FlowLayout(FlowLayout.CENTER,0,0));
		dateEnd.add(new JLabel("Fin"));
		dateEnd.add(datePicker2);
		
		JButton plus =new JButton("Ajouter");
		
		plus.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				java.sql.Date selectedDateBegin = (java.sql.Date) datePicker.getModel().getValue();
				java.sql.Date selectedDateEnd = (java.sql.Date) datePicker2.getModel().getValue();
				if(selectedDateBegin!=null && selectedDateEnd!=null && !filtre_capteur.getSelectedItem().equals("---Chosir le capteur---") && nb<3) {
					query="SELECT * FROM valeur where Date>'"+selectedDateBegin.toString()+"' AND Date<'"+selectedDateEnd.toString()+"' AND NomC='"+filtre_capteur.getSelectedItem()+"'";
					System.out.println(query);
					try {
						ResultSet rst=d.executerRequete(query);
						String capteur=(String) filtre_capteur.getSelectedItem();
						XYSeries serie = new XYSeries(capteur);

						while(rst.next()) {
							Float value=rst.getFloat("Valeur");
							double sqlDate=rst.getTimestamp("Date").getTime();
							serie.add(sqlDate, value);
						}
						if(dataset.getSeriesIndex(serie.getKey())==-1) {
							dataset.addSeries(serie);
							chart=ChartFactory.createXYLineChart("","Date", "Value",dataset,PlotOrientation.VERTICAL, true, true, false);
							DateAxis xAxis = new DateAxis();
							chart.getXYPlot().setDomainAxis(xAxis);
							chartPanel.updateUI();
							chartPanel.revalidate();
							nb++;
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
			
		});
		
		/*----------------------CHART----------------------------------*/
		
		
		header.add(filtre_fluide);
		header.add(filtre_capteur);
		header.add(dateBegin);
		header.add(dateEnd);
		header.add(plus);
		DateAxis xAxis = new DateAxis();
		chart.getXYPlot().setDomainAxis(xAxis);
		chartPanel.setDomainZoomable(true);
		chartPanel.setRangeZoomable(true);
		chartPanel.setMouseZoomable(true);
		
		XYPlot plot = chart.getXYPlot();
		XYLineAndShapeRenderer renderer =new XYLineAndShapeRenderer();
		//renderer.setSeriesStroke(0, new BasicStroke(5.0f));
		//renderer.setSeriesStroke(1, new BasicStroke(5.0f));
		renderer.setBaseStroke(new BasicStroke(5.0f));
		renderer.setAutoPopulateSeriesStroke(false);
		plot.setRenderer(renderer);
		
		JButton reset=new JButton("Reset Chart");
		reset.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dataset.removeAllSeries();
				chartPanel.updateUI();
				chartPanel.revalidate();
				nb=0;
			}
		});
		
		bottom.add(reset);
		this.add(header,BorderLayout.PAGE_START);
		this.add(chartPanel,BorderLayout.CENTER);
		this.add(bottom,BorderLayout.PAGE_END);
	}
	
	public class DateLabelFormatter extends AbstractFormatter {
		private static final long serialVersionUID = 1L;
		private String datePattern = "yyyy-MM-dd";
	    private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);

	    @Override
	    public Object stringToValue(String text) throws ParseException {
	        return dateFormatter.parseObject(text);
	    }

	    @Override
	    public String valueToString(Object value) throws ParseException {
	        if (value != null) {
	            Calendar cal = (Calendar) value;
	            return dateFormatter.format(cal.getTime());
	        }

	        return "";
	    }

	}
}
