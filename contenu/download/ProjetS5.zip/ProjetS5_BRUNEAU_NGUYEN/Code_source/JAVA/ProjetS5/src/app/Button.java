package app;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Button extends JPanel{
	private static final long serialVersionUID = 1L;
	JLabel title;

	Button(String m, String imgPath){
		ImageIcon image_navbar = new ImageIcon(imgPath);
		
		Image newImage = image_navbar.getImage().getScaledInstance(-1, -1, Image.SCALE_SMOOTH);
		image_navbar = new ImageIcon(newImage);
				
		JLabel container_image_navbar = new JLabel();
		container_image_navbar.setIcon(image_navbar);
		
		title = new JLabel(m,JLabel.CENTER);
		title.setFont(new Font("Serif", Font.BOLD,13));
		title.setForeground(new Color(0x09105A));

		
		this.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
            	Object src = e.getSource();
        		if (src == NavBar.live_button) {
        			NavBar.live_button.setBackground(new Color(0xF3F3F3));
        			
        			NavBar.posteriori_button.setBackground(new Color(0xC1C1C1));
        			
        			NavBar.gestion_button.setBackground(new Color(0xC1C1C1));
        			CardLayout cl = (CardLayout)(Frame.content.getLayout());
        		    cl.show(Frame.content,"live");
        		}
        		else if(src == NavBar.posteriori_button) {
        			NavBar.live_button.setBackground(new Color(0xC1C1C1));
        			
        			NavBar.posteriori_button.setBackground(new Color(0xF3F3F3));
        			
        			NavBar.gestion_button.setBackground(new Color(0xC1C1C1));
        			CardLayout cl = (CardLayout)(Frame.content.getLayout());
        		    cl.show(Frame.content,"chart");
        			
        		}
        		else if(src == NavBar.gestion_button) {
        			NavBar.live_button.setBackground(new Color(0xC1C1C1));
        			
        			NavBar.posteriori_button.setBackground(new Color(0xC1C1C1));
        			
        			NavBar.gestion_button.setBackground(new Color(0xF3F3F3));
        			CardLayout cl = (CardLayout)(Frame.content.getLayout());
        		    cl.show(Frame.content,"tree");
        			
        		}
            }
		});
		
		Box line1=new Box(BoxLayout.X_AXIS);
		line1.add(Box.createHorizontalGlue());
		line1.add(container_image_navbar);
		line1.add(Box.createHorizontalGlue());
		Box line2=new Box(BoxLayout.X_AXIS);
		line2.add(Box.createHorizontalGlue());
		line2.add(title);
		line2.add(Box.createHorizontalGlue());
		this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
		this.setBackground(new Color(0xC1C1C1));
		this.add(Box.createVerticalGlue());
		this.add(line1);
		this.add(line2);
		this.add(Box.createVerticalGlue());

	}
	
	public JLabel getTitle() {
		return title;
	}
		
}
