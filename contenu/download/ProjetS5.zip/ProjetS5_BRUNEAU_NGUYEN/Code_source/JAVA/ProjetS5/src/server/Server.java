package server;

import java.io.*;
import java.net.*;
import java.sql.Timestamp;
import java.util.TreeMap;

import java.util.Map.Entry;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import capteur.Capteur;
import content.Gestion;
import content.Table;
import database.Database;

public class Server implements Runnable {

	Database d = new Database();
	private Timestamp sqlDate ;
	public static TreeMap<String, Capteur> capteurs = new TreeMap<>();
	public static TreeMap<String, Capteur> cloneCapteurs = new TreeMap<>();
	public static int PORT = 8952;
	Socket socket;
	ServerSocket server;

	public Server() {
		try {
			server = new ServerSocket(PORT);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		try {
			while (!server.isClosed()) {
				socket = server.accept();
				Thread t = new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							BufferedReader plec = new BufferedReader(new InputStreamReader(socket.getInputStream()));
							boolean socketOuvert = true;
							while (socketOuvert) {
								try {
									String input = plec.readLine();
									if (input != null) {
										handleInput(input);
									}
								} catch (SocketException se) {
									socketOuvert = false;
								}
							}
							socket.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				});
				t.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handleInput(String input) {
		if (input.contains("Connexion")) {
			String[] parts = input.split(" ", 3);
			String[] description = parts[2].split(":");
			Capteur c= new Capteur(parts[1],description[0],description[1],description[2],description[3],true);
			if(!capteurs.containsKey(parts[1])) {
				capteurs.put(parts[1], c);
				d.addToTableCapteur(parts[1], description[0],description[1], description[2], description[3],c.getMin(),c.getMax(),true);
				DefaultTreeModel model = (DefaultTreeModel)Gestion.tree.getModel();
				DefaultMutableTreeNode root = (DefaultMutableTreeNode)model.getRoot();
				d.miseAJourTree(root);
				model.reload(root);
			}
			else {
				capteurs.get(parts[1]).setActive(true);
				d.changeActive(parts[1], true);
			}
		}
		if (input.contains("Donnee")) {
			String[] parts = input.split(" ");	
			sqlDate = new java.sql.Timestamp(new java.util.Date().getTime());
			d.addToTableValeur(parts[1], Float.parseFloat(parts[2]), sqlDate);
			capteurs.get(parts[1]).addValue(Float.parseFloat(parts[2]));
		}
		if (input.contains("Deconnexion")) {
			String[] parts = input.split(" ");
			capteurs.get(parts[1]).setActive(false);
			d.changeActive(parts[1], false);
		}
		cloneCapteurs.clear();
		for (Entry<String, Capteur> entry : capteurs.entrySet()) {
			if (entry.getValue().isActive()) {
				cloneCapteurs.put(entry.getKey(), entry.getValue());
			}
		}
		
		Table.modele.filter(Table.filtre_fluide.getSelectedItem(),Table.filtre_batiment.getSelectedItem());
		Table.modele.fireTableDataChanged();
	}
}
