package app;

import java.awt.CardLayout;
import java.awt.Color;

import javax.swing.JPanel;

import content.Chart;
import content.Live;
import content.Tree;

public class Content extends JPanel{
	private static final long serialVersionUID = 1L;

	Content(){
		this.setBackground(Color.WHITE);
		this.setLayout(new CardLayout());
		this.add(new Live(),"live");
		this.add(new Chart(),"chart");
		this.add(new Tree(),"tree");
	}
}
