package app;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import server.Server;



public class Frame {
	static Content content;
	Frame(){
		JFrame frame = new JFrame("Projet S5");
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    int port=Integer.parseInt(JOptionPane.showInputDialog(frame,"Connection au server",8952));
	    Server.PORT=port;
	    BorderLayout layout = new BorderLayout();
		frame.setLayout(layout);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
	    NavBar navbar = new NavBar();
	    content= new Content();
	    frame.add(navbar,BorderLayout.LINE_START);
	    frame.add(content,BorderLayout.CENTER);
	    frame.pack();
	    frame.setLocationRelativeTo(null);
	    frame.setVisible(true);
	}
}
