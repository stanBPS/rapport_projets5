package content;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Live extends JPanel{
	private static final long serialVersionUID = 1L;

	public Live(){
		this.setBackground(Color.WHITE);
		this.setLayout(new BorderLayout());
		
		JPanel header =new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel titre =new JLabel("VISUALISATION TEMPS R�EL");
		titre.setFont(new Font("Serif", Font.BOLD,26));
		titre.setForeground(new Color(0x09105A));
		
		header.setBackground(new Color(0xC1C1C1));
		header.add(titre);
		this.add(header,BorderLayout.PAGE_START);
		this.add(new Table(),BorderLayout.CENTER);

		
	}

}
