package app;

import javax.swing.SwingUtilities;

import server.Server;

public class AppMain {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
	        public void run() {
	            new Frame();
	            Server c = new Server();
	            Thread t = new Thread(c);
	            t.start();
	        }
	    });
	}

}
