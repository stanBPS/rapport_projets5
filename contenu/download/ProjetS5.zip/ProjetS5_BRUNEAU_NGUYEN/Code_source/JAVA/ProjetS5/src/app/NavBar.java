package app;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class NavBar extends JPanel{
	private static final long serialVersionUID = 1L;
	static Button live_button;
	static Button posteriori_button;
	static Button gestion_button;
	NavBar(){
		
		this.setBackground(new Color(0xC8C8C8));
		
		
		
		//Menu
		ImageIcon image_navbar = new ImageIcon("images/UPS.png");
				
		//changer taille de l'image
		Image newImage = image_navbar.getImage().getScaledInstance(256, -1, Image.SCALE_SMOOTH);
		image_navbar = new ImageIcon(newImage);
				
		JLabel container_image_navbar = new JLabel();
		container_image_navbar.setIcon(image_navbar);
		
				
				
		/*-----------------BUTTON MENU------------------*/
				
		live_button = new Button("VISUALISATION TEMPS R�EL","images/sensor.png");
				
		posteriori_button = new Button("ANALYSE A POSTERIORI","images/stats.png");
				
		gestion_button = new Button("GESTION DES CAPTEURS","images/tree-structure.png");
		
		live_button.setBackground(new Color(0xF3F3F3));
		Box col=new Box(BoxLayout.Y_AXIS);
		Box line1=new Box(BoxLayout.X_AXIS);
		line1.add(container_image_navbar);
		col.add(line1);
		col.add(Box.createVerticalGlue());
		col.add(live_button);
		col.add(Box.createRigidArea(new Dimension(0, 5)));
		col.add(posteriori_button);
		col.add(Box.createRigidArea(new Dimension(0, 5)));
		col.add(gestion_button);
		col.add(Box.createVerticalGlue());

		this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));

		this.add(col);
	}
}
