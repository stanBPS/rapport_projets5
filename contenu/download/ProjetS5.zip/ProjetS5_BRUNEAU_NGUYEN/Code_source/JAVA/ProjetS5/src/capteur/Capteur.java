package capteur;

import java.util.ArrayList;
import java.util.List;

public class Capteur {
	private String nom;
	private String type;
	private String batiment;
	private String etage;
	private String lieu;
	private float min;
	private float max;
	private boolean active;
	private List<Float> list;

	public Capteur(String nom, String type, String batiment, String etage, String lieu, boolean active) {
		this.nom = nom;
		this.type = type;
		this.batiment = batiment;
		this.etage = etage;
		this.lieu = lieu;
		this.active = active;
		this.list = new ArrayList<>();
		switch (this.type) {
		case "EAU":
			this.min = 0;
			this.max = 10;
			break;
		case "ELECTRICITE":
			this.min = 10;
			this.max = 500;
			break;
		case "AIRCOMPRIME":
			this.min = 0;
			this.max = 5;
			break;
		case "TEMPERATURE":
			this.min = 17;
			this.max = 22;
			break;
		default:
			this.min = 0;
			this.max = 0;
		}
	}

	public List<Float> getList() {
		return list;
	}

	public void addValue(float v) {
		list.add(v);
	}

	public String getNom() {
		return nom;
	}

	public String getType() {
		return type;
	}

	public String getBatiment() {
		return batiment;
	}

	public String getEtage() {
		return etage;
	}

	public String getLieu() {
		return lieu;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean equals(Object obj) {
		if (obj instanceof Capteur) {
			Capteur capteur = (Capteur) obj;
			return nom.equals(capteur.getNom());
		}
		return false;
	}

	@Override
	public String toString() {
		return nom;
	}

	public float getMin() {
		return min;
	}

	public void setMin(float min) {
		this.min = min;
	}

	public float getMax() {
		return max;
	}

	public void setMax(float max) {
		this.max = max;
	}

	public boolean isRed() {
		if (list.size() > 0) {
			if (list.get(list.size() - 1) < this.min || list.get(list.size() - 1) > this.max) {
				return true;
			}
		}
		return false;
	}
}
